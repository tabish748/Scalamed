export function findDrugPricesByZipPayload() {
    return {
        name: '',
        sortBy: '',
        type: '',
        zipCode:''
    };
  }