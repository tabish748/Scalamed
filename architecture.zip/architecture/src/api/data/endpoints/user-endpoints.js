export const USER_CREATE = '.create';
export const USER_LOGIN = '.login';