export const FIND_SEARCH_TERM_SUGGESTIONS = '.findSearchTermSuggestions';
export const FIND_DRUG_PRICES_BY_ZIP = '.findDrugPricesByZip';
